
/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/
let handler = async (m, { conn, text, usedPrefix, command }) => {
  m.reply(
    `Link Group : *[ ` + gc + ` ]*`,
  );
};
handler.help = ["groupchat"]
handler.tags = ["main"];
handler.command = ["groupchat"];
module.exports = handler;