const yts = require('yt-search');
const axios = require('axios');

const formatNumber = (number) => {
    return new Intl.NumberFormat().format(number);
};

const Ytdl = {
    search: async (query) => {
        try {
            const result = (await yts(query)).videos;
            if (result.length === 0) throw new Error('Tidak ada hasil ditemukan.');
            return {
                status: true,
                creator: '@Bang_syaii',
                data: result.map(video => ({
                    title: video.title,
                    url: 'https://youtu.be/' + video.videoId,
                    img: video.image,
                    author: {
                        name: video.author.name,
                        url: video.author.url
                    },
                    duration: video.duration.timestamp
                }))
            };
        } catch (error) {
            return {
                status: false,
                msg: 'Data tidak dapat ditemukan!',
                err: error.message
            };
        }
    },
    mp3: async (url) => {
        try {
            const { data: audioData } = await axios.post('https://api.cobalt.tools/api/json', {
                url: url,
                filenamePattern: 'basic',
                asFormat: 'opus',
                isAudioOnly: true
            }, {
                headers: {
                    Accept: 'application/json',
                    origin: 'https://cobalt.tools',
                    referer: 'https://cobalt.tools/',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
                }
            });

            const videoData = (await yts(url)).videos[0];
            const channelData = (await yts(videoData.author.name)).channels[0];

            return {
                status: true,
                msg: 'Berhasil mengunduh audio!',
                media: audioData.url,
                title: videoData.title,
                metadata: {
                    id: videoData.videoId,
                    duration: videoData.timestamp,
                    thumbnail: videoData.image,
                    views: formatNumber(videoData.views),
                    description: videoData.description
                },
                author: {
                    name: channelData.name,
                    url: channelData.url,
                    bio: channelData.about,
                    avatar: channelData.image,
                    subscriber: formatNumber(channelData.subCount)
                }
            };
        } catch (error) {
            return {
                status: false,
                msg: 'Gagal mengunduh audio!',
                err: error.message
            };
        }
    },
};

const handler = async (m, { conn, command, text, usedPrefix }) => {
    if (!text) return conn.reply(m.chat, 'Masukkan query pencarian', m);

    conn.sendMessage(m.chat, {
        react: {
            text: '🕒',
            key: m.key,
        },
    });

    try {
        // Langkah 1: Pencarian video
        const searchData = await Ytdl.search(text);
        if (!searchData.status || searchData.data.length === 0) {
            throw new Error('Tidak ada hasil yang ditemukan.');
        }

        const video = searchData.data[0];  // Mengambil video pertama dari hasil pencarian

        // Langkah 2: Mengunduh MP3 dari hasil pencarian
        const downloadData = await Ytdl.mp3(video.url);
        if (!downloadData.status) {
            throw new Error('Gagal mengunduh MP3.');
        }

        const fakee = {
            key: {
                fromMe: false,
                participant: '13135550002@s.whatsapp.net',
                remoteJid: '13135550002@s.whatsapp.net',
            },
            message: {
                groupInviteMessage: {
                    groupJid: '6282389924037-1625305606@g.us',
                    inviteCode: 'null',
                    groupName: 'Panxz',
                    caption: `Durasi: ${downloadData.metadata.duration} Menit`,
                },
            },
        };

        await conn.sendMessage(m.chat, {
            document: await Func.fetchBuffer(downloadData.metadata.thumbnail),  // Thumbnail video
            mimetype: 'audio/mpeg',
            fileName: downloadData.title,
            caption: `
🎥 *< Video Info >* 🎥
━━━━━━━━━━━━━
✨ *Title*: ${downloadData.title}
🔗 *Url*: ${video.url}
⏱️ *Duration*: ${downloadData.metadata.duration}
👁️ *Views*: ${downloadData.metadata.views} views
📝 *Description*: ${downloadData.metadata.description || 'No description available'}

👤 *< Author Info >* 👤
━━━━━━━━━━━━━
👑 *Name*: ${downloadData.author.name}
🔗 *Link*: ${downloadData.author.url}
📜 *Bio*: ${downloadData.author.bio || 'No bio available'}
👥 *Subscribers*: ${downloadData.author.subscriber} subscribers`,
            fileLength: 99999999999999999,
            jpegThumbnail: await Func.reSize(await Func.fetchBuffer(downloadData.metadata.thumbnail), 200, 100),
        }, { quoted: m });

        // Mengirim file audio ke pengguna
        conn.sendFile(m.chat, downloadData.media, null, null, fakee);

        conn.sendMessage(m.chat, {
            react: {
                text: '✅',
                key: m.key,
            },
        });
    } catch (e) {
        console.log(e);
        m.reply('Gagal mendapatkan data!');
    }
};

handler.help = ['play'].map((v) => v + ' *<query>*');
handler.tags = ['downloader'];
handler.command = /^play$/i;

handler.exp = 0;
handler.limit = true;
handler.register = true;

module.exports = handler;