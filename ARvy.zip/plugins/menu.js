/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/
const moment = require("moment-timezone");
const fs = require("fs");
const Canvas = require('canvas');
const { loadImage } = require('canvas');
const { color } = require('../lib/color');
const canvafy = require('canvafy');
const fetch = require("node-fetch");
const os = require("os");
const totalMemory = os.totalmem();
const freeMemory = os.freemem();
const usedMemory = totalMemory - freeMemory;
const {
  generateWAMessageFromContent,
  proto, 
  prepareWAMessageMedia,
} = require("@whiskeysockets/baileys");


let menulist = async (m, { conn, usedPrefix, command, args }) => {
  
  const perintah = args[0] || "tags";
  const tagCount = {};
  const tagHelpMapping = {};
const user = global.db.data.users[m.sender] 


  Object.keys(global.plugins)
    .filter((plugin) => !plugin.disabled)
    .forEach((plugin) => {
      const tagsArray = Array.isArray(global.plugins[plugin].tags)
        ? global.plugins[plugin].tags
        : [];

      if (tagsArray.length > 0) {
        const helpArray = Array.isArray(global.plugins[plugin].help)
          ? global.plugins[plugin].help
          : [global.plugins[plugin].help];

        tagsArray.forEach((tag) => {
          if (tag) {
            if (tagCount[tag]) {
              tagCount[tag]++;
              tagHelpMapping[tag].push(...helpArray);
            } else {
              tagCount[tag] = 1;
              tagHelpMapping[tag] = [...helpArray];
            }
          }
        });
      }
    });

  let help = Object.values(global.plugins)
    .filter((plugin) => !plugin.disabled)
    .map((plugin) => {
      return {
        help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: "customPrefix" in plugin,
        limit: plugin.limit,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      };
    });

  if (perintah === "tags") {
    const daftarTag = Object.keys(tagCount)
      .sort()
      .join(`\n@=> ${usedPrefix + command} `);
    const more = String.fromCharCode(8206);
    const readMore = more.repeat(4001);
    let fitur = Object.values(plugins)
    .filter((v) => v.help && !v.disabled)
    .map((v) => v.help)
    .flat(1);
  let totalf = Object.values(global.plugins).filter(
    (v) => v.help && v.tags,
  ).length;
  const user = global.db.data.users[m.sender];
  let hasil = fitur.length;

  let uptime = process.uptime();
  let hari = Math.floor(uptime / 86400);
  uptime %= 86400;
  let jam = Math.floor(uptime / 3600);
  uptime %= 3600;
  let menit = Math.floor(uptime / 60);
  let detik = Math.floor(uptime % 60);
  let runtime = `${hari}D ${jam}H ${menit}M ${detik}S`;
    
let dashboard = `
═════════════════════
\`</> D A S H B O A R D </>\`
═════════════════════
🌟 Hai *@${m.sender.split("@")[0]}*, Aku Adalah *${namebot}*, Bot Whatsapp Yang Akan Membantu Anda Dalam Banyak Hal Di Whatsapp. Jika Anda Menemukan Bug Atau Error, Mohon Laporkan Kepada Owner.

═════════════════════
\`</> B O T - I N F O </>\`
═════════════════════
🔧 *Bot Name*: ${namebot}  
👤 *Owner*: *${nameown}*  
🧑‍💼 *Tag Owner*: *@${nomorown.split("@")[0]}*
🔢 *Version*: ${version}  
🌐 *Mode*: ${global.opts['self'] ? 'Self' : 'Public'}  
👥 *Total Users*: ${Object.keys(global.db.data.users).length}  
💬 *Total Chats*: ${Object.keys(conn.chats).length}  
📋 *Total Menus*: ${hasil}  
🗃️ *Database Size*: ${Func.formatSize(fs.statSync("database.json").size)}  
⏳ *Runtime*: ${runtime}  
💾 *Free Memory*: ${Func.formatSize(freeMemory)}  
📦 *Total Memory*: ${Func.formatSize(totalMemory)}  
📉 *Used Memory*: ${Func.formatSize(usedMemory)}  

═════════════════════
\`</> U S E R - I N F O </>\`
═════════════════════
👤 *Name*: ${db.data.users[m.sender].name}  
🏷️ *Tag*: *@${m.sender.split("@")[0]}*  
💵 *Balance*: ${db.data.users[m.sender].saldo}  
🎂 *Age*: ${db.data.users[m.sender].age || 0}  
🔢 *Limit*: ${db.data.users[m.sender].limit}  
📈 *Exp*: ${db.data.users[m.sender].exp}  
🏆 *Level*: ${db.data.users[m.sender].level}  
🌟 *Premium*: ${user.premium ? "✅" : "❌"}  
🔖 *Role*: *[ ${db.data.users[m.sender].role} ]*  
🏦 *Bank*: ${db.data.users[m.sender].bank}  
💰 *Money*: ${db.data.users[m.sender].money || 0}  

═════════════════════
\`</> L I S T - M E N U </>\`
═════════════════════
@=> ${usedPrefix + command} all  
@=> ${usedPrefix + command} ${daftarTag}
═════════════════════
`;

let pz;

if (global.menu === "button") {
    pz = `${dashboard}
@=> ${usedPrefix + command} all
@=> ${usedPrefix + command} ${daftarTag}
═════════════════════
`;
}

    if (global.menu === "simple") {
let pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/1ecdb5a0aee62ef17d7fc.jpg");
conn.sendMessage(m.chat, {
    text: dashboard,
    contextInfo: {
          mentionedJid: [m.sender],
          forwardingScore: 999,
          isForwarded: true,
      externalAdReply: {  
        title: namebot + ' By ' + nameown,
        body: `Hello </> ${m.name} </>`,
        thumbnailUrl: await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg'),
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: false      }
    }
  }, { quoted: fkontak });
conn.sendMessage(m.chat, 
  {
    audio: {
      url: audioz,
      mimetype: "audio/mpeg",
    },
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender],
      businessMessageForwardInfo: { 
        businessOwnerJid: nomorown + "@s.whatsapp.net" 
      },
      forwardedNewsletterMessageInfo: {
        newsletterName: wm,
        newsletterJid: idsaluran
      },
      externalAdReply: {  
        title: namebot + ' By ' + nameown,
        body: `Hello </> ${m.name} </>`,
        thumbnailUrl: await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg'),
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  },
  { quoted: fkontak }
);
    } else if (global.menu === "doc") {

let user = global.db.data.users[m.sender];
let name = user.name || m.sender;
let ppUrl = await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg');
let pp = await (await fetch(ppUrl)).buffer();

let shiroo = new canvafy.LevelUp()
    .setUsername(name)
    .setBackground('image', 'https://telegra.ph/file/0aed699be76b28e2ea3d4.jpg')
    .setAvatar(pp)
    .setBorder('#A9A9A9')
    .setAvatarBorder('#A9A9A9')
    .setOverlayOpacity(1.0);

let levelUpImage = await shiroo.build();

let maxWidth = 400;
let maxHeight = 150;

let resizedLevelUpImage = await conn.resize(levelUpImage, maxWidth, maxHeight).catch(() => null);

await conn.sendMessage(m.chat, {
    document: fs.readFileSync("./package.json"),
    fileName: namebot,
    fileLength: fs.statSync("./package.json").size,
    pageCount: "2024",
    caption: dashboard,
    mimetype: 'application/json',
    jpegThumbnail: resizedLevelUpImage,
    contextInfo: {
        externalAdReply: {
            title: namebot + ' By ' + nameown,
            body: `Hello </> ${m.name} </>`,
            thumbnailUrl: ppUrl,
            sourceUrl: saluran,
            mediaType: 1,
            renderLargerThumbnail: true,
        },
        forwardingScore: 10,
        isForwarded: true,
        mentionedJid: [m.sender],
        businessMessageForwardInfo: {
            businessOwnerJid: `${nomorown}@s.whatsapp.net`
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: idsaluran,
            serverMessageId: null,
            newsletterName: global.botdate + " || " + namebot + "  🟢",
        }
    }
}, { quoted: { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: wm } } });
conn.sendMessage(m.chat, 
  {
    audio: {
      url: audioz,
      mimetype: "audio/mpeg",
    },
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender],
      businessMessageForwardInfo: { 
        businessOwnerJid: nomorown + "@s.whatsapp.net" 
      },
      forwardedNewsletterMessageInfo: {
        newsletterName: wm,
        newsletterJid: idsaluran
      },
      externalAdReply: {  
        title: namebot + ' By ' + nameown,
        body: `Hello </> ${m.name} </>`,
        thumbnailUrl: await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg'),
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  },
  { quoted: fkontak }
);
    }  else if (global.menu === "payment") {
      await conn.relayMessage(
        m.chat,
        {
          requestPaymentMessage: {
            currencyCodeIso4217: "USD",
            amount1000:
              Object.values(plugins)
                .filter((v) => v.help && !v.disabled)
                .map((v) => v.help)
                .flat(1).length * 1000,
            requestFrom: m.sender,
            noteMessage: {
              extendedTextMessage: {
                text: dashboard,
                contextInfo: {
                  mentionedJid: conn.parseMention(dashboard),
                  externalAdReply: {
                    showAdAttribution: true,
                  },
                },
              },
            },
          },
        },
        {},
      );
      conn.sendMessage(m.chat, 
  {
    audio: {
      url: audioz,
      mimetype: "audio/mpeg",
    },
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender],
      businessMessageForwardInfo: { 
        businessOwnerJid: nomorown + "@s.whatsapp.net" 
      },
      forwardedNewsletterMessageInfo: {
        newsletterName: wm,
        newsletterJid: idsaluran
      },
      externalAdReply: {  
        title: namebot + ' By ' + nameown,
        body: `Hello </> ${m.name} </>`,
        thumbnailUrl: await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg'),
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  },
  { quoted: fkontak }
);
    } else if (global.menu === "button") {
      const list = Object.keys(tagCount);
let array = [];
for (let i of list) {
  array.push({
    header: `🚀 MENU ${i.toUpperCase()}`,
    title: `🔍 Category [ ${i} ]`,
    description: `🌟 Explore more features of ${i} here!`,
    id: `${usedPrefix + command} ${i}`,
  });
}

let sections = [
  {
    title: "🌐 MAIN MENU",
    highlight_label: "🔍 Discover All Features",
    rows: [
      {
        header: namebot,
        title: "MAIN MENU",
        description: "🌟 Explore All Bot Menu Here",
        id: ".menu all",
      },
    ],
  },
  {
    title: "👤 OWNER",
    highlight_label: "📞 Contact the Owner",
    rows: [
      {
        header: "👤 OWNER",
        title: "Bot Owner",
        description: "📧 Send a Message to the Owner",
        id: ".owner",
      },
    ],
  },
  {
    title: "💻 SCRIPT",
    highlight_label: "💻 View Source Code",
    rows: [
      {
        header: "💻 SOURCE CODE",
        title: "Script",
        description: "💻 Information About the Bot Script",
        id: ".sc",
      },
    ],
  },
  {
    title: "📈 SERVER STATUS",
    highlight_label: "📊 Server Information",
    rows: [
      {
        header: "📈 SERVER PERFORMANCE",
        title: "Ping Server",
        description: "🌐 Check the Performance and Status of the Bot Server",
        id: ".ping",
      },
    ],
  },
  {
    title: "🌟 BOT FEATURES",
    highlight_label: `🚀 Welcome to ${namebot}!`,
    rows: [...array],
  },
];

let listMessage = {
  title: "🚀 Explore All Menu 🚀",
  sections,
};
let ppUrl = await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg');
let panz = await getCircularProfilePicture(ppUrl);

let Shirokuu = generateWAMessageFromContent(m.from, {
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: dashboard,
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "━━━━━━━━━━━━━━━━━━━━\n🛠 Script developed by Pan Pan\n🔒 Do not sell or share this script!\n━━━━━━━━━━━━━━━━━━━━",
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: null,
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia({ 
              document: { 
                url: saluran 
              }, 
              mimetype: 'image/webp', 
              fileName: `${m.name}`, 
              pageCount: 2024, 
              jpegThumbnail: await Func.reSize(panz, 400, 400), 
              fileLength: 2024000 
            }, { upload: conn.waUploadToServer }))
          }),
          contextInfo: {
            forwardingScore: 2024,
            isForwarded: true,
            mentionedJid: [m.sender, nomorown + "@s.whatsapp.net"],
            forwardedNewsletterMessageInfo: {
              newsletterJid: global.idsaluran,
              serverMessageId: null,
              newsletterName: `🗓️ ${namebot} - Simple Whatsapp Bot! 🟢`,
            },
            externalAdReply: {
              showAdAttribution: true,
              title: `</> Hello, Welcome To ${namebot} </>`,
              body: `🕰️ ${global.bottime}`,
              mediaType: 1,
              sourceUrl: `https://${namebot}/By/${nameown}`,
              thumbnailUrl: thumb,
              renderLargerThumbnail: true
            }
          },
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [                                            {
                          name: "single_select",
                          buttonParamsJson: JSON.stringify(listMessage),
                        },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "💬 Group Chat",
                  id: ".groupchat",
                }),
              },
            ]
          })
        })
      }
    }
}, { quoted: fkontak });

conn.relayMessage(m.key.remoteJid, Shirokuu.message, {
    messageId: m.key.id
});
  
await conn.sendMessage(m.chat, 
  {
    audio: {
      url: audioz,
      mimetype: "audio/mpeg",
    },
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender],
      businessMessageForwardInfo: { 
        businessOwnerJid: nomorown + "@s.whatsapp.net" 
      },
      forwardedNewsletterMessageInfo: {
        newsletterName: wm,
        newsletterJid: idsaluran
      },
      externalAdReply: {  
        title: namebot + ' By ' + nameown,
        body: `Hello </> ${m.name} </>`,
        thumbnailUrl: await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg'),
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  },
  { quoted: fkontak }
);
    } else {
      conn.sendMessage(
        m.chat,
        {
          text: dashboard,
          contextInfo: {
            mentionedJid: conn.parseMention(dashboard),
            externalAdReply: {
              title: `© ${namebot} [ ver ${version} ]\n• Uptime: ${Func.toDate(process.uptime() * 1000)}`,
              body: wm,
              thumbnailUrl: thumb,
              sourceUrl: sgc,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: fkontak },
      );
    }
  } else if (tagCount[perintah]) {
    const daftarHelp = tagHelpMapping[perintah]
  .map((helpItem) => {
    return `${helpItem}`;
  })
  .join("\n│   └─ ");

let dashboard = `
┌───────
│   ${daftarHelp}
└───────
`;

    if (global.menu === "simple") {
      conn.reply(m.chat, dashboard, fkontak);
    } else if (global.menu === "doc") {
      conn.sendMessage(m.chat, {
            document: fs.readFileSync("./package.json"),
            fileName: namebot,
            fileLength: 20239999999999,
            pageCount: "2023",
            caption: dashboard,
            contextInfo: {
              externalAdReply: {
                containsAutoReply: true,
                mediaType: 1,
                mediaUrl: '',
                renderLargerThumbnail: true,
                showAdAttribution: true,
                sourceUrl: '',
                thumbnailUrl: thumb,
                title: wm, 
                body: `© ${namebot}`,
              },
            },
          });
    } else if (global.menu === "payment") {
      await conn.relayMessage(
        m.chat,
        {
          requestPaymentMessage: {
            currencyCodeIso4217: "USD",
            amount1000:
              Object.values(plugins)
                .filter((v) => v.help && !v.disabled)
                .map((v) => v.help)
                .flat(1).length * 1000,
            requestFrom: m.sender,
            noteMessage: {
              extendedTextMessage: {
                text: dashboard,
                contextInfo: {
                  mentionedJid: conn.parseMention(dashboard),
                  externalAdReply: {
                    showAdAttribution: true,
                  },
                },
              },
            },
          },
        },
        {},
      );
      conn.sendMessage(m.chat, 
  {
    audio: {
      url: audioz,
      mimetype: "audio/mpeg",
    },
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender],
      businessMessageForwardInfo: { 
        businessOwnerJid: nomorown + "@s.whatsapp.net" 
      },
      forwardedNewsletterMessageInfo: {
        newsletterName: wm,
        newsletterJid: idsaluran
      },
      externalAdReply: {  
        title: namebot + ' By ' + nameown,
        body: `Hello </> ${m.name} </>`,
        thumbnailUrl: await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg'),
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  },
  { quoted: fkontak }
);
    } else if (menu === "button") {
     conn.sendButton(m.chat, [["💬 Group Chat!", ".groupchat"]], fkontak, {
    body: dashboard, 
    url: thumb, 
    })
     conn.sendMessage(m.chat, 
  {
    audio: {
      url: audioz,
      mimetype: "audio/mpeg",
    },
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender],
      businessMessageForwardInfo: { 
        businessOwnerJid: nomorown + "@s.whatsapp.net" 
      },
      forwardedNewsletterMessageInfo: {
        newsletterName: wm,
        newsletterJid: idsaluran
      },
      externalAdReply: {  
        title: namebot + ' By ' + nameown,
        body: `Hello </> ${m.name} </>`,
        thumbnailUrl: await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg'),
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  },
  { quoted: fkontak }
);
    } else {
      conn.sendMessage(
        m.chat,
        {
          text: dashboard,
          contextInfo: {
            mentionedJid: conn.parseMention(dashboard),
            externalAdReply: {
              title: `© ${namebot} [ ver ${version} ]\n• Uptime: ${Func.toDate(process.uptime() * 1000)}`,
              body: wm,
              thumbnailUrl: thumb,
              sourceUrl: sgc,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: fkontak },
      );
    }
  } else if (perintah === "all") {
    let fitur = Object.values(plugins)
    .filter((v) => v.help && !v.disabled)
    .map((v) => v.help)
    .flat(1);
  let totalf = Object.values(global.plugins).filter(
    (v) => v.help && v.tags,
  ).length;
  const user = global.db.data.users[m.sender];
  let hasil = fitur.length;
  const more = String.fromCharCode(8206);
  const readMore = more.repeat(4001);
  let uptime = process.uptime();
  let hari = Math.floor(uptime / 86400);
  uptime %= 86400;
  let jam = Math.floor(uptime / 3600);
  uptime %= 3600;
  let menit = Math.floor(uptime / 60);
  let detik = Math.floor(uptime % 60);
  let runtime = `${hari}D ${jam}H ${menit}M ${detik}S`;
    const allTagsAndHelp = Object.keys(tagCount)
  .map((tag) => {
    const daftarHelp = tagHelpMapping[tag]
      .map((helpItem) => {
        return `${usedPrefix + helpItem}`;
      })
      .join("\n│   └─ ");

    return Func.Styles(`
┌─【 *\`</> ${tag.toUpperCase()} </>\`* 】─┐
│
│   ├─ ${daftarHelp}
│
└───────────────────┘
`);
  })
  .join("\n");
    let dashboard = `
═════════════════════
\`</> D A S H B O A R D </>\`
═════════════════════
🌟 Hai *@${m.sender.split("@")[0]}*, Aku Adalah *${namebot}*, Bot Whatsapp Yang Akan Membantu Anda Dalam Banyak Hal Di Whatsapp. Jika Anda Menemukan Bug Atau Error, Mohon Laporkan Kepada Owner.

═════════════════════
\`</> B O T - I N F O </>\`
═════════════════════
🔧 *Bot Name*: ${namebot}  
👤 *Owner*: *${nameown}*  
🧑‍💼 *Tag Owner*: *@${nomorown.split("@")[0]}*
🔢 *Version*: ${version}  
🌐 *Mode*: ${global.opts['self'] ? 'Self' : 'Public'}  
👥 *Total Users*: ${Object.keys(global.db.data.users).length}  
💬 *Total Chats*: ${Object.keys(conn.chats).length}  
📋 *Total Menus*: ${hasil}  
🗃️ *Database Size*: ${Func.formatSize(fs.statSync("database.json").size)}  
⏳ *Runtime*: ${runtime}  
💾 *Free Memory*: ${Func.formatSize(freeMemory)}  
📦 *Total Memory*: ${Func.formatSize(totalMemory)}  
📉 *Used Memory*: ${Func.formatSize(usedMemory)}  

═════════════════════
\`</> U S E R - I N F O </>\`
═════════════════════
👤 *Name*: ${db.data.users[m.sender].name}  
🏷️ *Tag*: *@${m.sender.split("@")[0]}*  
💵 *Balance*: ${db.data.users[m.sender].saldo}  
🎂 *Age*: ${db.data.users[m.sender].age || 0}  
🔢 *Limit*: ${db.data.users[m.sender].limit}  
📈 *Exp*: ${db.data.users[m.sender].exp}  
🏆 *Level*: ${db.data.users[m.sender].level}  
🌟 *Premium*: ${user.premium ? "✅" : "❌"}  
🔖 *Role*: *[ ${db.data.users[m.sender].role} ]*  
🏦 *Bank*: ${db.data.users[m.sender].bank}  
💰 *Money*: ${db.data.users[m.sender].money || 0}  

═════════════════════
\`</> A L L - M E N U </>\`
═════════════════════

${allTagsAndHelp}`;

    if (global.menu === "simple") {
      conn.reply(m.chat, dashboard, fkontak);
    } else if (global.menu === "doc") {
      conn.sendMessage(m.chat, {
            document: fs.readFileSync("./package.json"),
            fileName: namebot,
            fileLength: 20239999999999,
            pageCount: "2023",
            caption: dashboard,
            contextInfo: {
              externalAdReply: {
                containsAutoReply: true,
                mediaType: 1,
                mediaUrl: '',
                renderLargerThumbnail: true,
                showAdAttribution: true,
                sourceUrl: '',
                thumbnailUrl: thumb,
                title: wm, 
                body: `© ${namebot}`,
              },
            },
          });
    }  else if (global.menu === "payment") {
      await conn.relayMessage(
        m.chat,
        {
          requestPaymentMessage: {
            currencyCodeIso4217: "USD",
            amount1000:
              Object.values(plugins)
                .filter((v) => v.help && !v.disabled)
                .map((v) => v.help)
                .flat(1).length * 1000,
            requestFrom: m.sender,
            noteMessage: {
              extendedTextMessage: {
                text: dashboard,
                contextInfo: {
                  mentionedJid: conn.parseMention(dashboard),
                  externalAdReply: {
                    showAdAttribution: true,
                  },
                },
              },
            },
          },
        },
        {},
      );
      conn.sendMessage(m.chat, 
  {
    audio: {
      url: audioz,
      mimetype: "audio/mpeg",
    },
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender],
      businessMessageForwardInfo: { 
        businessOwnerJid: nomorown + "@s.whatsapp.net" 
      },
      forwardedNewsletterMessageInfo: {
        newsletterName: wm,
        newsletterJid: idsaluran
      },
      externalAdReply: {  
        title: namebot + ' By ' + nameown,
        body: `Hello </> ${m.name} </>`,
        thumbnailUrl: await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg'),
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  },
  { quoted: fkontak }
);
    } else if (global.menu === "button") {
      const list = Object.keys(tagCount);
let array = [];
for (let i of list) {
  array.push({
    header: `🚀 MENU ${i.toUpperCase()}`,
    title: `🔍 Category [ ${i} ]`,
    description: `🌟 Explore more features of ${i} here!`,
    id: `${usedPrefix + command} ${i}`,
  });
}

let sections = [
  {
    title: "🌐 MAIN MENU",
    highlight_label: "🔍 Discover All Features",
    rows: [
      {
        header: namebot,
        title: "MAIN MENU",
        description: "🌟 Explore All Bot Menu Here",
        id: ".menu all",
      },
    ],
  },
  {
    title: "👤 OWNER",
    highlight_label: "📞 Contact the Owner",
    rows: [
      {
        header: "👤 OWNER",
        title: "Bot Owner",
        description: "📧 Send a Message to the Owner",
        id: ".owner",
      },
    ],
  },
  {
    title: "💻 SCRIPT",
    highlight_label: "💻 View Source Code",
    rows: [
      {
        header: "💻 SOURCE CODE",
        title: "Script",
        description: "💻 Information About the Bot Script",
        id: ".sc",
      },
    ],
  },
  {
    title: "📈 SERVER STATUS",
    highlight_label: "📊 Server Information",
    rows: [
      {
        header: "📈 SERVER PERFORMANCE",
        title: "Ping Server",
        description: "🌐 Check the Performance and Status of the Bot Server",
        id: ".ping",
      },
    ],
  },
  {
    title: "🌟 BOT FEATURES",
    highlight_label: `🚀 Welcome to ${namebot}!`,
    rows: [...array],
  },
];

let listMessage = {
  title: "🚀 Explore All Menu 🚀",
  sections,
};

let ppUrl = await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg');
let panz = await getCircularProfilePicture(ppUrl);

let Shirokuu = generateWAMessageFromContent(m.from, {
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: dashboard,
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "━━━━━━━━━━━━━━━━━━━━\n🛠 Script developed by Pan Pan\n🔒 Do not sell or share this script!\n━━━━━━━━━━━━━━━━━━━━",
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: null,
            hasMediaAttachment: true,
            ...(await prepareWAMessageMedia({ 
              document: { 
                url: saluran 
              }, 
              mimetype: 'image/webp', 
              fileName: `>> ${m.name} <<`, 
              pageCount: 2024, 
              jpegThumbnail: await Func.reSize(panz, 400, 400), 
              fileLength: 2024000 
            }, { upload: conn.waUploadToServer }))
          }),
          contextInfo: {
            forwardingScore: 2024,
            isForwarded: true,
            mentionedJid: [m.sender, nomorown + "@s.whatsapp.net"],
            forwardedNewsletterMessageInfo: {
              newsletterJid: global.idsaluran,
              serverMessageId: null,
              newsletterName: `🗓️ ${namebot} - Simple Whatsapp Bot! 🟢`,
            },
            externalAdReply: {
              showAdAttribution: true,
              title: `</> Hello, Welcome To ${namebot} </>`,
              body: `🕰️ ${global.bottime}`,
              mediaType: 1,
              sourceUrl: `https://${namebot}/By/${nameown}`,
              thumbnailUrl: thumb,
              renderLargerThumbnail: true
            }
          },
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [                                            {
                          name: "single_select",
                          buttonParamsJson: JSON.stringify(listMessage),
                        },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "💬 Group Chat",
                  id: ".groupchat",
                }),
              },
            ]
          })
        })
      }
    }
}, { quoted: fkontak });

conn.relayMessage(m.key.remoteJid, Shirokuu.message, {
    messageId: m.key.id
});
  
await conn.sendMessage(m.chat, 
  {
    audio: {
      url: audioz,
      mimetype: "audio/mpeg",
    },
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender],
      businessMessageForwardInfo: { 
        businessOwnerJid: nomorown + "@s.whatsapp.net" 
      },
      forwardedNewsletterMessageInfo: {
        newsletterName: wm,
        newsletterJid: idsaluran
      },
      externalAdReply: {  
        title: namebot + ' By ' + nameown,
        body: `Hello </> ${m.name} </>`,
        thumbnailUrl: await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/241b747767455c4bcfc7b.jpg'),
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  },
  { quoted: fkontak }
);
    } else {
      conn.sendMessage(
        m.chat,
        {
          text: dashboard,
          contextInfo: {
            mentionedJid: conn.parseMention(dashboard),
            externalAdReply: {
              title: `© ${namebot} [ ver ${version} ]\n• Uptime: ${Func.toDate(process.uptime() * 1000)}`,
              body: wm,
              thumbnailUrl: thumb,
              sourceUrl: sgc,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: fkontak },
      );
    }
  } else {
    await conn.reply(
      m.chat,
      `*Maaf Menu ${perintah.toUpperCase()} Tidak Ditemukan*`,
      m,
    );
  }
};

menulist.help = ["menu"]
menulist.tags = ["main"];
menulist.command = ["menu"];
menulist.register = true
module.exports = menulist;

async function getCircularProfilePicture(url) {
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    const buffer = Buffer.from(response.data, 'binary');
    const img = await loadImage(buffer);
    const canvas = Canvas.createCanvas(img.width, img.height);
    const ctx = canvas.getContext('2d');
    ctx.beginPath();
    ctx.arc(img.width / 2, img.height / 2, img.width / 2, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(img, 0, 0, img.width, img.height);
    return canvas.toBuffer();
}