
/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/
const fetch = require('node-fetch');

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `mw tanya apa?`;

  await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});

  try {
    let p = await llama3(text) 
    await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
    await conn.sendMessage(m.chat, {
      text: p,
      contextInfo: {
        externalAdReply: {  
          title: "L L A M A  A I",
          body: wm,
          thumbnailUrl: 'https://files.catbox.moe/w01s4x.png',
          sourceUrl: saluran,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });
  } catch (error) {
    await conn.sendMessage(m.chat, `Terjadi kesalahan: ${error.message}`);
  }
};

handler.command = handler.help = ['llama'];
handler.tags = ['ai'];
handler.premium = false;
handler.register = true;

module.exports = handler;

const model = '70b'
async function llama3(query) {
if (!["70b", "8b"].some(qq => model == qq)) model = "70b"; //correct
try {
    const BASE_URL = 'https://llama3-enggan-ngoding.vercel.app/api/llama'; //@Irulll
    const payload = {
        messages: [
    {
      role: "system",
      content: `kamu adalah AI yang bernama llama AI`
    },
    {
      role: "user",
      content: query
    }
  ],
  model: '70b'
    };
    const response = await fetch(BASE_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.1 Mobile/15E148',
        },
        body: JSON.stringify(payload),
    });
    const data = await response.json();
    return data.output;
        } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}