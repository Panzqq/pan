/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/
const axios = require("axios");

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `enter text`;
  let hasil = await pz(text)
  m.reply(hasil) 
};
handler.command = handler.help = ['ai3'];
handler.tags = ['ai'];
handler.premium = false;
handler.register = true
module.exports = handler;

async function pz(txt) {
    try {
        var api = await axios.get(`https://hercai.onrender.com/turbo/hercai?question=${encodeURIComponent(txt)}`, {
            headers: {
                "content-type": "application/json",
            },
        })
        return api.data.reply;
    } catch (e) {
    console.log(e)
}
}