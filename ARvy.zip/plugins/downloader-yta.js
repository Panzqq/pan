/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/
const yts = require('yt-search');
const axios = require('axios');

const getVideoId = (url) => {
    const match = url.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/[^\/\n\s]+\/|(?:v|e(?:mbed)?)\/|[^v\r\n\s]+?\/|user\/[^\/\n\s]+|embed\/|videoseries\?list=)|(?:youtu\.)?be(?:\.com)?\/(?:watch\?v=|v\/|u\/\w\/|embed\/|watch\?v%3Dd%2026|watch\?v-|-+|watch\/|-+|v=)?)((\w|-){11}).*/);
    if (match) {
        return match[1];
    }
    throw new Error('Invalid YouTube URL');
};

const formatNumber = (number) => {
    return new Intl.NumberFormat().format(number);
};

const Ytdl = {
    search: async (query) => {
        try {
            const result = (await yts(query)).videos;
            return {
                status: true,
                creator: '@Bang_syaii',
                data: result.map(video => ({
                    title: video.title,
                    url: 'https://youtu.be/' + video.videoId,
                    img: video.image,
                    author: {
                        name: video.author.name,
                        url: video.author.url
                    }
                }))
            };
        } catch (error) {
            return {
                status: false,
                msg: 'Data tidak dapat ditemukan!',
                err: error.message
            };
        }
    },
    mp3: async (url) => {
        try {
            const videoId = getVideoId(url);
            const videoUrl = (await yts(videoId)).videos[0].url;
            const { data: audioData } = await axios.post('https://api.cobalt.tools/api/json', {
                url: videoUrl,
                filenamePattern: 'basic',
                asFormat: 'opus',
                isAudioOnly: true
            }, {
                headers: {
                    Accept: 'application/json',
                    origin: 'https://cobalt.tools',
                    referer: 'https://cobalt.tools/',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
                }
            });

            const video = (await yts('https://youtu.be/' + videoId)).videos[0];
            const channel = (await yts(video.author.name)).channels[0];

            return {
                status: true,
                creator: '@Bang_syaii',
                msg: 'Success Download Content!',
                title: video.title || new Date().toISOString(),
                metadata: {
                    id: video.videoId,
                    duration: video.timestamp,
                    thumbnail: video.image,
                    views: formatNumber(video.views),
                    description: video.description
                },
                author: {
                    name: channel.name,
                    url: channel.url,
                    bio: channel.about,
                    avatar: channel.image,
                    subscriber: formatNumber(channel.subCount)
                },
                url: 'https://youtu.be/' + videoId,
                media: audioData.url
            };
        } catch (error) {
            return {
                status: false,
                msg: 'Gagal saat mengambil data!',
                err: error.message
            };
        }
    },
};

const handler = async (m, { conn, command, text, usedPrefix }) => {
    if (!text) throw '*Masukkan URL*';

    try {
        const downloadData = await Ytdl.mp3(text);
  await conn.sendMessage(m.chat, {
    text: `</> Video Info </>\n*Title*: ${downloadData.title}\n*Url*: ${downloadData.url}\n*ID*: ${downloadData.metadata.id}\n*Duration*: ${downloadData.metadata.duration}\n*Views*: ${downloadData. metadata.views}\n*Description*: ${downloadData.metadata.description}\n\n</> Author Info </>\n*Name*: ${downloadData.author.name}\n*Link*: ${downloadData.author.url}\n*Bio*: ${downloadData.author.bio}\n*Subscriber*: ${downloadData.author.subscriber}`,
    contextInfo: {
      externalAdReply: {  
        title: downloadData.title,
        body: wm,
        thumbnailUrl: downloadData.metadata.thumbnail, 
        sourceUrl: downloadData.url,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m });

conn.sendFile(m.chat, downloadData.media, null, null, m);
    } catch (error) {
        throw `Error: ${error.message}`;
    }
};

handler.help = ["yta"];
handler.tags = ["downloader"];
handler.command = /^(yta|ytmp3)$/i;

module.exports = handler;