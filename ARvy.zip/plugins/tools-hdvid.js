
/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/
const ffmpeg = require('fluent-ffmpeg');
const fs = require('fs');

const handler = async (m, { conn }) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender;
  let name = await conn.getName(who);
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';
  if (!mime) throw `Video tidak ditemukan`;
  
  let inputFilePath = await conn.downloadAndSaveMediaMessage(q, './tmp/input-video');
  let outputFilePath = './tmp/video.mp4';
  
  ffmpeg(inputFilePath)
    .outputOptions('-s', '1920x1080')
    .save(outputFilePath)
    .on('end', () => {
      conn.sendFile(m.chat, outputFilePath, '', `Nih Kak`, m);
      fs.unlinkSync(inputFilePath); // Hapus file input setelah selesai
      fs.unlinkSync(outputFilePath); // Hapus file output setelah selesai
    })
    .on('error', (err) => {
      console.error(err);
      m.reply('Terjadi kesalahan saat meningkatkan resolusi video. ' + err.message);
      fs.unlinkSync(inputFilePath); // Hapus file input jika terjadi error
      if (fs.existsSync(outputFilePath)) fs.unlinkSync(outputFilePath); // Hapus file output jika terjadi error
    });
};

handler.command = handler.help = ["hdvid"];
handler.tags = ["tools"];
handler.limit = true;

module.exports = handler;