let fetch = require('node-fetch');
let uploadFile = require('../lib/uploadFile.js');
let axios = require('axios');

let handler = async (m, { conn, usedPrefix, command, text, isOwner }) => {
  if (!text) throw `Use ${usedPrefix + command} a girl and cute cat`;
  
  conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });
  
  try {
    let res = await prodia(text);
    if (res.status) {
      await new Promise(resolve => setTimeout(resolve, 4000));
      conn.sendFile(m.chat, res.imageUrl, 'text2img.jpg', 'Done', m);
    } else {
      m.reply(res.message);
    }
  } catch (e) {
    console.log(e);
    m.reply('An error occurred while processing your request.');
  }
};

handler.help = ['prodia'];
handler.tags = ['ai'];
handler.command = /^(prodia)$/i;
module.exports = handler;

async function prodia(text) {
  try {
    const response = await axios.get('https://api.prodia.com/generate', {
      params: {
        new: true,
        prompt: text,
        model: 'absolutereality_v181.safetensors [3d9d4d2b]',
        negative_prompt: '',
        steps: 20,
        cfg: 7,
        seed: 1736383137,
        sampler: 'DPM++ 2M Karras',
        aspect_ratio: 'square'
      },
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Referer': 'https://app.prodia.com/'
      }
    });

    if (response.status === 200) {
      const jobId = response.data.job;
      const imageUrl = `https://images.prodia.xyz/${jobId}.png`;
      return {
        status: true,
        imageUrl: imageUrl
      };
    } else {
      return {
        status: false,
        message: 'Request cannot be processed'
      };
    }
  } catch (error) {
    if (error.response) {
      return {
        status: false,
        message: `Error: ${error.response.status} - ${error.response.statusText}`
      };
    } else if (error.request) {
      return {
        status: false,
        message: 'No response from the server.'
      };
    } else {
      return {
        status: false,
        message: error.message
      };
    }
  }
}