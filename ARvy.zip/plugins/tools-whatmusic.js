
/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/
const fetch = require("node-fetch");
const FormData = require("form-data");
const crypto = require("crypto");

class kwontl {
    constructor(config = {}) {
        this.endpoint = "/v1/identify";
        this.signature_version = "1";
        const { host, data_type, audio_format, sample_rate, audio_channels } = config;
        this.host = host || "identify-eu-west-1.acrcloud.com";
        this.access_key = "764c336a37d8aba46511828c186f5f49";
        this.access_secret = "6eif1xo9HdX1xuYFSTvCCdwsbVro39ejQ52spCK8";
        this.data_type = data_type || "audio";
        this.audio_format = audio_format || "";
        this.sample_rate = sample_rate || "";
        this.audio_channels = audio_channels || 2;
    }

    buildStringToSign(method, uri, accessKey, dataType, signatureVersion, timestamp) {
        return [method, uri, accessKey, dataType, signatureVersion, timestamp].join("\n");
    }

    sign(string, access_secret) {
        return crypto
            .createHmac("sha1", access_secret)
            .update(Buffer.from(string, "utf-8"))
            .digest()
            .toString("base64");
    }

    generateFormData(object) {
        const form = new FormData();
        Object.keys(object).forEach((key) => {
            form.append(key, object[key]);
        });
        return form;
    }

    async downloadAudioFromURL(url) {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`Failed to download audio: ${response.statusText}`);
        return await response.buffer();
    }

    async z(url) {
        const audio_sample = await this.downloadAudioFromURL(url);
        return this.identify(audio_sample);
    }

    identify(audio_sample) {
        const current_date = new Date();
        const timestamp = current_date.getTime() / 1000;
        const stringToSign = this.buildStringToSign("POST", this.endpoint, this.access_key, this.data_type, this.signature_version, timestamp);
        const signature = this.sign(stringToSign, this.access_secret);
        const formData = {
            sample: audio_sample,
            access_key: this.access_key,
            data_type: this.data_type,
            signature_version: this.signature_version,
            signature: signature,
            sample_bytes: audio_sample.length,
            timestamp: timestamp
        };

        return fetch(`https://${this.host}${this.endpoint}`, {
            method: "POST",
            body: this.generateFormData(formData)
        }).then((response) => response.json());
    }
}

let handler = async (m, { conn, usedPrefix, command }) => {
    if (!m.quoted) throw 'Reply to an audio message!';
    
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    
    if (!/audio/.test(mime)) throw `Reply to an audio file with command, e.g., *${usedPrefix + command}*`;
    
    let audioBuffer = await q.download();
    
    let catboxUrl;
    try {
        catboxUrl = await Uploader.catbox(audioBuffer);
    } catch (err) {
        throw 'Failed to upload audio to Catbox!';
    }

    const acr = new kwontl({});

    try {
        let result = await acr.z(catboxUrl);
        if (result.status.code === 0 && result.metadata && result.metadata.music && result.metadata.music.length > 0) {
            let music = result.metadata.music[0];
            let title = music.title || 'Unknown';
            let artists = music.artists.map(a => a.name).join(', ') || 'Unknown artist';
            let album = music.album.name || 'Unknown album';
            let releaseDate = music.release_date || 'Unknown release date';
            let genres = music.genres ? music.genres.map(g => g.name).join(', ') : 'Unknown genres';
            let label = music.label || 'Unknown label';

            let message = `*Title:* ${title}\n` +
                          `*Artists:* ${artists}\n` +
                          `*Album:* ${album}\n` +
                          `*Release Date:* ${releaseDate}\n` +
                          `*Genres:* ${genres}\n` +
                          `*Label:* ${label}`;

            m.reply(message);
        } else {
            m.reply('Music not found!');
        }
    } catch (err) {
        m.reply(`Error identifying music: ${err.message}`);
    }
};

handler.help = handler.command = ['whatmusic'];
handler.tags = ['tools'];
module.exports = handler;