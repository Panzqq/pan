/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/
const uploadFile = require('../lib/uploadFile.js');
const fetch = require('node-fetch');
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 

let handler = async (m, { args, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    if (!mime) throw 'No media found';
    
    let media = await q.download();
    let fileSizeMB = media.length / (1024 * 1024);
    if (fileSizeMB > 10) {
        throw 'Max file size is 10 MB.';
    }

    let link = await Uploader.catbox(media);
    let caption = `
📮 *L I N K :* ${link} 
📊 *S I Z E :* ${formatBytes(media.length)}`;
let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: caption, 
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: true,
                ...(await prepareWAMessageMedia(
                  { image: { url: "https://files.catbox.moe/00uury.png" } },
                  { upload: conn.waUploadToServer },
                )),
              }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
              "name": "cta_copy",
              "buttonParamsJson": `{"display_text":"🔗 Copy Link","id":"123456789","copy_code":"${link}"}`
              }
           ],
          })
        })
    }
  }
}, { quoted: m })

await conn.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}

handler.help = ['tourl'];
handler.tags = ['tools'];
handler.command = /^(tourl)$/i;
handler.limit = true;
module.exports = handler;

function formatBytes(bytes) {
    if (bytes === 0) {
        return '0 B';
    }
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / 1024 ** i).toFixed(2)} ${sizes[i]}`;
}

async function shortUrl(url) {
    let res = await fetch(`https://tinyurl.com/api-create.php?url=${url}`);
    return await res.text();
}