/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Masukkan pertanyaan!`;
  let pz = await youbot(text) 
  m.reply(pz)
};
handler.command = handler.help = ['youbot'];
handler.tags = ['ai'];
handler.premium = false;
handler.register = true
module.exports = handler;

async function youbot(text) {
    const url = 'https://app.yoursearch.ai/api';
    const data = {
        searchTerm: text,
        promptTemplate: "Istilah pencarian: \"{searchTerm}\"\n\nBuatlah ringkasan dari hasil pencarian dalam tiga paragraf dengan nomor referensi, yang kemudian Anda daftarkan secara bernomor di bagian bawah.\nSertakan emoji dalam ringkasan.\nPastikan untuk menyertakan nomor referensi dalam ringkasan.\nBaik dalam teks ringkasan maupun daftar referensi, nomor referensi harus terlihat seperti ini: \"(1)\".\nRumuskan kalimat-kalimat sederhana.\nSertakan baris kosong antara paragraf.\nJangan memulai dengan pengantar, tetapi langsung mulai dengan ringkasan.\nSertakan emoji dalam ringkasan.\nDi akhir, tulis teks petunjuk di mana saya bisa menemukan hasil pencarian sebagai perbandingan dengan istilah pencarian di atas dengan tautan ke pencarian Google dalam format ini `Lihat hasil Google: ` dan tambahkan tautannya.\nDi bawah ini tuliskan tip bagaimana saya bisa mengoptimalkan hasil pencarian untuk kueri pencarian saya.\nSaya tunjukkan dalam format berikut:\n\n```\n<Ringkasan hasil pencarian dengan nomor referensi>\n\nSumber:\n(1) <URL referensi pertama>\n(2) <URL referensi kedua>\n\n<Teks petunjuk untuk hasil pencarian lebih lanjut dengan tautan Google>\n<Tip>\n```\n\nBerikut adalah hasil pencarian:\n{searchResults}",
        searchParameters: "{}",
        searchResultTemplate: "[{order}] \"{snippet}\"\nURL: {link}"
    };

    const headers = {
        'Content-Type': 'application/json'
    };

    try {
        const response = await axios.post(url, data, {
            headers
        });
        console.log('POST request successful!');
        console.log(response.data);
        return response.data.response;
    } catch (error) {
        console.error('Error making POST request:', error);
        throw error;
    }
}