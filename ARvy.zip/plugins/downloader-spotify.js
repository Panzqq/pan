/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
═════════════════════════════════════
*/
const { spotifydl } = require('../scrape/spotify-dl');

const handler = async (m, { conn, command, text, usedPrefix }) => {

  if (!text) throw '*Masukkan URL*';

  const xz = /^https:\/\/open\.spotify\.com\/(track|album|playlist|artist|episode|show)\/[a-zA-Z0-9]{22}(?:\?si=[a-zA-Z0-9_-]{22})?$/;

  if (!xz.test(text)) {
    throw '*URL harus dari Spotify*';
  }

  try {
    const pz = await spotifydl(text);

    await conn.sendMessage(m.chat, {
      text: `</> Data </>\n*Url*: ${text}\n*Title*: ${pz.title}\n*Duration*: ${pz.durasi}\n*Creator*: ${pz.artis}\n*Type*: ${pz.type}`,
      contextInfo: {
        externalAdReply: {  
          title: pz.title,
          body: 'Spotify Downloader',
          thumbnailUrl: pz.image, 
          sourceUrl: text,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });

    await conn.sendFile(m.chat, pz.download, `${pz.title}.mp3`, null, m);

  } catch (error) {
    throw `Error: ${error.message}`;
  }
};

handler.help = handler.command = ["spotifydl", "spotifydownload"];
handler.tags = ["downloader"];

module.exports = handler;