/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/
const fetch = require('node-fetch');

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `mw tanya apa?`;

  await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});

  try {
    let p = await axios.get(`https://hercai.onrender.com/v3/hercai?question=${text}`)
    await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
    await conn.sendMessage(m.chat, {
      text: p.data.reply,
      contextInfo: {
        externalAdReply: {  
          title: "H E R C A I",
          body: wm,
          thumbnailUrl: 'https://files.catbox.moe/ofo9mz.png',
          sourceUrl: saluran,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });
  } catch (error) {
    await conn.sendMessage(m.chat, `Terjadi kesalahan: ${error.message}`);
  }
};

handler.command = handler.help = ['hercai'];
handler.tags = ['ai'];
handler.premium = false;
handler.register = true;

module.exports = handler;