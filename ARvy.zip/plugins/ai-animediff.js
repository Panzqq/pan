/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/

let handler = async (m, { conn, usedPrefix, command, text, isOwner }) => {
 if (!text) throw `Use ${usedPrefix + command} a girl and cute cat`
	conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
try {
    let res = await sdxlAnime(text) 
    conn.sendFile(m.chat, res.image, 'text2img.jpg', done, m) 
 } catch (e) {
    console.log(e) 
    m.reply(eror) 
  }
}
handler.help = handler.command = ['animediff','animdiff']
handler.tags = ['ai']
module.exports = handler

 async function sdxlAnime(prompt) {
  try {
    return await new Promise(async(resolve, reject) => {
      if(!prompt) return reject("failed reading undefined prompt!");
      axios.post("https://aiimagegenerator.io/api/model/predict-peach", {
        prompt,
        negativePrompt: "nsfw, nude, uncensored, cleavage, nipples",
        key: "Soft-Anime",
        width: 512,
        height: 768,
        quantity: 1,
        size: "512x768"
      }).then(res => {
        const data = res.data;
        if(data.code !== 0) return reject(data.message);
        if(data.data.safetyState === "RISKY") return reject("nsfw image was generated, you try create other image again!")
        if(!data.data?.url) return reject("failed generating image!")
        return resolve({
          status: true,
          image: data.data.url
        })
      }).catch(reject)
    })
  } catch (e) {
    return {
      status: false,
      message: e
    }
  }
}