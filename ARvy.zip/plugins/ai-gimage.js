
/*════════════════════════════════════
  ├ Weem Gweh Jier
  ├ WhatsApp: wa.me/62857021072505
  ├ Jangan Perjual Belikan Esce Ini!  
═════════════════════════════════════
*/
const axios = require('axios');
const cheerio = require('cheerio');

let handler = async (m, { conn, text }) => {
    if (!text) {
        return conn.reply(m.chat, `Usage: gimage <query>`, m);
    }

    conn.reply(m.chat, 'Please wait...', m);

    const nyariGambar = async (query) => {
        const url = `https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=isch`;
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        let images = [];
        $('img').each((i, elem) => {
            images.push($(elem).attr('src'));
        });
        return images;
    };

    try {
        let images = await nyariGambar(text);
        if (images.length === 0) {
            return conn.reply(m.chat, 'No images found.', m);
        }
        let imageAvz = images[Math.floor(Math.random() * images.length)];
        conn.sendMessage(m.chat, { image: { url: imageAvz }, caption: `*Query* : ${text}\n*Media Url* : ${imageAvz}` }, { quoted: m });
    } catch (error) {
        conn.reply(m.chat, 'An error occurred.', m);
    }
};

handler.help = handler.command = ['gimage', 'image'];
handler.tags = ['ai'];

module.exports = handler;