var os = require("os");
var { sizeFormatter } = require("human-readable");
var format = sizeFormatter({
  std: "JEDEC", // 'SI' (default) | 'IEC' | 'JEDEC'
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
});

function maskIp(ip) {
  return ip.replace(/(\d+)\.(\d+)\.(\d+)\.(\d+)$/, 'XXX.XXX.XXX.$4');
}

function clockString(ms) {
  var d = isNaN(ms) ? "--" : Math.floor(ms / 86400000);
  var h = isNaN(ms) ? "--" : Math.floor(ms / 3600000) % 24;
  var m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
  var s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
  return [d, "D ", h, "H ", m, "M ", s, "S "]
    .map((v) => v.toString().padStart(2, 0))
    .join("");
}

var handler = async (m, { conn }) => {
  const used = process.memoryUsage();
  const cpus = os.cpus().map((cpu) => {
    cpu.total = Object.keys(cpu.times).reduce(
      (last, type) => last + cpu.times[type],
      0,
    );
    return cpu;
  });
  const cpu = cpus.reduce(
    (last, cpu, _, { length }) => {
      last.total += cpu.total;
      last.speed += cpu.speed / length;
      last.times.user += cpu.times.user;
      last.times.nice += cpu.times.nice;
      last.times.sys += cpu.times.sys;
      last.times.idle += cpu.times.idle;
      last.times.irq += cpu.times.irq;
      return last;
    },
    {
      speed: 0,
      total: 0,
      times: {
        user: 0,
        nice: 0,
        sys: 0,
        idle: 0,
        irq: 0,
      },
    },
  );

  var _muptime;
  if (process.send) {
    process.send("uptime");
    _muptime =
      (await new Promise((resolve) => {
        process.once("message", resolve);
        setTimeout(resolve, 1000);
      })) * 1000;
  }
  var muptime = clockString(_muptime);

  var networkInterfaces = os.networkInterfaces();
  var networkInfo = Object.keys(networkInterfaces)
    .map(iface => {
      return `*• ${iface}:* ${
        networkInterfaces[iface].map(
          net => `IP: ${maskIp(net.address)} (Family: ${net.family}, Internal: ${net.internal})`
        ).join('\n')
      }`;
    })
    .join('\n\n');

  var txt = `
═════════════════════
*[ SERVER REPORT ]*
═════════════════════
*• User:* ${process.env.USER || "Not Found"}
*• Node Version:* ${process.version || "Not Found"}
*• NPM Version:* ${process.env.npm_config_user_agent ? process.env.npm_config_user_agent.split(' ')[1] : "Not Found"}
*• Command Run:* ${process.env.CMD_RUN || "Not Found"}
*• IP Address:* ${maskIp(process.env.SERVER_IP) || "Not Found"}
*• Internal IP:* ${maskIp(process.env.INTERNAL_IP) || "Not Found"}
*• Hostname:* ${os.hostname() || "Not Found"}
*• OS Platform:* ${process.platform || "Not Found"}
*• OS Release:* ${os.release() || "Not Found"}
*• OS Arch:* ${os.arch() || "Not Found"}
*• CPU Model:* ${os.cpus()[0].model || "Not Found"}
*• CPU Cores:* ${os.cpus().length || "Not Found"}
*• Average Load (1m, 5m, 15m):* ${os.loadavg().map(n => n.toFixed(2)).join(', ')}
*• Total Memory:* ${(os.totalmem() / 1024 / 1024).toFixed(2)} MB
*• Free Memory:* ${(os.freemem() / 1024 / 1024).toFixed(2)} MB
*• Uptime:* ${Math.floor(process.uptime() / 3600)} hours ${Math.floor((process.uptime() % 3600) / 60)} minutes
*• Memory Usage:* ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)} MB
*• Swap Total:* ${(os.totalmem() - os.freemem()).toFixed(2)} MB

═════════════════════
_NodeJS Memory Usage_
═════════════════════
${Object.keys(used)
    .map(
      (key, _, arr) =>
        `${key.padEnd(Math.max(...arr.map((v) => v.length)), " ")}: ${format(
          used[key],
        )}`,
    )
    .join("\n")
}

${
  cpus[0]
    ? `🔄 _Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times)
        .map(
          (type) =>
            `- *${(type + "*").padEnd(6)}: ${(
              (100 * cpu.times[type]) /
              cpu.total
            ).toFixed(2)}%`,
        )
        .join("\n")}

🔧 _CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus
  .map(
    (cpu, i) =>
      `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(
        cpu.times,
      )
        .map(
          (type) =>
            `- *${(type + "*").padEnd(6)}: ${(
              (100 * cpu.times[type]) /
              cpu.total
            ).toFixed(2)}%`,
        )
        .join("\n")}`,
  )
  .join("\n\n")}`
    : ""
}

📡 *Network Interfaces* 📡
═════════════════════
${networkInfo}
═════════════════════`;

  conn.sendMessage(m.chat, {
    text: txt,
    contextInfo: {
      externalAdReply: {  
        title: "I N F O  S E R V E R",
        body: namebot,
        thumbnailUrl: 'https://telegra.ph/file/cf4f28ed3b9ebdfb30adc.png',
        sourceUrl: saluran,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m });
};

handler.help = ["ping", "speed"].map((a) => a + " *[get info server]*");
handler.tags = ["info"];
handler.command = ["ping", "speed"];

module.exports = handler;