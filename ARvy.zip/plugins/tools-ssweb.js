var fs = require('fs');
var path = require('path');
var fetch = require('node-fetch');
var handler = async (m, { conn, command, args, text }) => {
if (!text) throw `*• Example :* ${command} *[url]*`;
    m.reply(wait);
    let url = Func.isUrl(text);
    for (let i of url) {
      conn.sendMessage(m.chat, {
        image: {
          url: `https://api.mightyshare.io/v1/19EIFDUEL496RA3F/jpg?url=${Func.isUrl(i) ? i : `https://${i}`}`,
        },
        caption: done,
      });
    }
}
handler.help = ['ssweb','sspc'];
handler.tags = ['tools'];
handler.command = ['ssweb', 'sspc', 'ss',]

handler.limit = true;
handler.fail = null;

module.exports = handler;