const WebSocket = require("ws");
const axios = require("axios");
const cheerio = require("cheerio");
const FormData = require("form-data");
const fetch = require("node-fetch");

function generateRandomUserAgent() {
  const androidVersions = [
    "4.0.3",
    "4.1.1",
    "4.2.2",
    "4.3",
    "4.4",
    "5.0.2",
    "5.1",
    "6.0",
    "7.0",
    "8.0",
    "9.0",
    "10.0",
    "11.0",
  ];
  const deviceModels = [
    "M2004J19C",
    "S2020X3",
    "Xiaomi4S",
    "RedmiNote9",
    "SamsungS21",
    "GooglePixel5",
  ];
  const buildVersions = [
    "RP1A.200720.011",
    "RP1A.210505.003",
    "RP1A.210812.016",
    "QKQ1.200114.002",
    "RQ2A.210505.003",
  ];
  const selectedModel =
    deviceModels[Math.floor(Math.random() * deviceModels.length)];
  const selectedBuild =
    buildVersions[Math.floor(Math.random() * buildVersions.length)];
  const chromeVersion =
    "Chrome/" +
    (Math.floor(Math.random() * 80) + 1) +
    "." +
    (Math.floor(Math.random() * 999) + 1) +
    "." +
    (Math.floor(Math.random() * 9999) + 1);
  const userAgent = `Mozilla/5.0 (Linux; Android ${androidVersions[Math.floor(Math.random() * androidVersions.length)]}; ${selectedModel} Build/${selectedBuild}) AppleWebKit/537.36 (KHTML, like Gecko) ${chromeVersion} Mobile Safari/537.36 WhatsApp/1.${Math.floor(Math.random() * 9) + 1}.${Math.floor(Math.random() * 9) + 1}`;
  return userAgent;
}

class Gemini {
  constructor(key, apikey) {
    this.conversation_id = '';
    this.response_id = '';
    this.choice_id = '';
    this.image_url = null;
    this.image_name = null;
    this.tools = [];
    this.params = { bl: '', _reqid: '', rt: 'c' };
    this.data = { 'f.req': '', at: '' };
    this.post_url = 'https://gemini.google.com/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate';
    this.headers = this.setupHeaders(key, apikey);
  }
  
  setupHeaders(key, apikey) {
    return {
      "Host": "gemini.google.com", "X-Same-Domain": "1", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8", "Sec-Fetch-Site": "same-origin", "Sec-Fetch-Mode": "cors", "Sec-Fetch-Dest": "empty", "Origin": "https://gemini.google.com", "Referer": "https://gemini.google.com/",
      "Cookie": `${key || '__Secure-1PSID'}=${apikey || 'g.a000gQhbTE4WvC7mwVL4CcWSxbt1Bde7Ady6qpt6951pafinWART4EEKmcskZMFX08uuSKwbvAACgYKAVYSAQASFQHGX2Mi1KAIQT0oz9dXZXKy0ioMBBoVAUF8yKpem3c3iJtHRDMQF3nSHOxU0076'}`
    };
  }
  
  async question(query) {
    try {
      const response = await fetch('https://gemini.google.com/', { method: 'GET', headers: this.headers });
      const geminiText = await response.text();
      const snlM0e = geminiText.match(/"SNlM0e":"(.*?)"/)?.[1] || '';
      const blValue = geminiText.match(/"cfb2h":"(.*?)"/)?.[1] || '';

      if (!snlM0e) {
        console.log("Authentication Error! Failed to retrieve SNlM0e pattern. Provide a valid __Secure-1PSID or __Secure-3PSID value.");
        return { content: "Authentication Error! Ensure correct __Secure-1PSID or __Secure-3PSID value." };
      }

      if (!blValue) {
        console.log("Value Error! Failed to retrieve bl value. Handle this case accordingly.");
        return { content: "Value Error! Handle this case accordingly." };
      }

      this.data.at = snlM0e;
      this.params.bl = blValue;

      let req_id = parseInt(Math.random().toString().slice(2, 6));
      const imageList = this.image_url ? [[[this.image_url, 1], this.image_name]] : [];
      const requestArray = [
        [query, 0, null, imageList, null, null, 0], ["en"], [this.conversation_id, this.response_id, this.choice_id, null, null, []],
        null, null, null, [1], 0, [], this.tools, 1, 0
      ];

      this.params._reqid = String(req_id);
      this.data['f.req'] = JSON.stringify([null, JSON.stringify(requestArray)]);
      
      const postData = `f.req=${encodeURIComponent(this.data['f.req'])}&at=${this.data.at}`;

      const urlWithParams = `${this.post_url}?${new URLSearchParams(this.params)}`;
      const responsePost = await fetch(urlWithParams, { method: 'POST', headers: this.headers, body: postData });
      if (!responsePost.ok) {
        console.log(`Response Status: ${responsePost.status}`);
        return { content: `Response Status: ${responsePost.status}` };
      }
      
      const resp_dict = JSON.parse((await responsePost.text()).split('\n')[3])[0][2];
      if (resp_dict === null) {
        console.log(`Response Error: ${responsePost.text}.`);
        return { content: `Response Error: ${responsePost.text}.` };
      }

      const parsed_answer = JSON.parse(resp_dict);
      const bard_answer = { content: parsed_answer[4][0][1][0], conversation_id: parsed_answer[1][0], response_id: parsed_answer[1][1], factualityQueries: parsed_answer[3], textQuery: parsed_answer[2] ? parsed_answer[2][0] : '', choices: parsed_answer[4].map((i) => ({ id: i[0], content: i[1] })) };
      this.conversation_id = bard_answer.conversation_id;
      this.response_id = bard_answer.response_id;
      this.choice_id = bard_answer.choices[0]?.id;
      req_id += 100000;
      return bard_answer;
    } catch (error) {
      console.error(error);
      return { content: `Error: ${error.message}` };
    }
  }
}

function generateRandomIP() {
  const octet = () => Math.floor(Math.random() * 256);
  return `${octet()}.${octet()}.${octet()}.${octet()}`;
}

async function talkai(type, message) {
  try {
    const headers = {
      "User-Agent": generateRandomUserAgent(),
      Referer: "https://talkai.info/id/chat/",
      "X-Forwarded-For": generateRandomIP(),
    };

    const data = {
      temperature: 1,
      frequency_penalty: 0,
      type: type,
      messagesHistory: [
        {
          from: "chatGPT",
          content:
            "Nama ku akiraa aku adalah maskot dari TalkAi sedang bisa membantu mu ðŸ˜‹ðŸ‘",
        },
        {
          from: "you",
          content: message,
        },
      ],
      message: message,
    };

    let response;

    try {
      response = await axios.post("https://talkai.info/id/chat/send/", data, {
        headers,
      });
    } catch (sendError) {
      console.error(
        'Error with "send" request. Falling back to "send2".',
        sendError,
      );
      // If "send" fails, try "send2"
      response = await axios.post("https://talkai.info/id/chat/send2/", data, {
        headers,
      });
    }

    return response.data;
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
  }
}
async function BlackBox(text) {
  return new Promise(async (resolve, reject) => {
    try {
      const danz = await axios.post(
        "https://www.useblackbox.io/chat-request-v4",
        {
          text: text,
          allMessages: [
            {
              user: text,
            },
          ],
          stream: "",
          clickedContinue: false,
        },
        {
          headers: {
            "Content-Type": "application/json",
            "User-Agent":
              "Mozilla/5.0 (Linux x86_64) Gecko/20130401 Firefox/71.3",
          },
        },
      );
      resolve(danz.data);
    } catch (e) {
      reject(e);
    }
  });
}
const soVits = {
  model: async (number) => {
    return new Promise(async (resolve) => {
      const { data } = await axios.get(
        "https://raw.githubusercontent.com/ArifzynXD/database/master/ai/anime.json",
      );
      const model = data.model[number.toString()];

      if (model) {
        resolve(model);
      } else {
        resolve(data);
      }
    });
  },
  language: async (id) => {
    return new Promise(async (resolve) => {
      const { data } = await axios.get(
        "https://raw.githubusercontent.com/ArifzynXD/database/master/ai/anime.json",
      );
      const lang = data.language[id.toString()];

      if (lang) {
        resolve(lang);
      } else {
        resolve(data);
      }
    });
  },
  generate: async (text, model_id, language) => {
    return new Promise(async (resolve, reject) => {
      const model = await this.model(model_id);
      const lang = await this.language(language);

      const send_hash = {
        session_hash: "4odx020bres",
        fn_index: 2,
      };
      const send_data = {
        fn_index: 2,
        data: [text, model, lang, 1, false],
        session_hash: "4odx020bres",
      };
      const result = {};

      const ws = new WebSocket(
        "wss://plachta-vits-umamusume-voice-synthesizer.hf.space/queue/join",
      );

      ws.onopen = function () {
        console.log("Connected to websocket");
      };

      ws.onmessage = async function (event) {
        let message = JSON.parse(event.data);
        switch (message.msg) {
          case "send_hash":
            ws.send(JSON.stringify(send_hash));
            break;
          case "estimation":
            console.log("Menunggu antrean: ï¸" + message.rank);
            break;
          case "send_data":
            console.log("Processing your audio....");
            ws.send(JSON.stringify(send_data));
            break;
          case "process_completed":
            result.url =
              "https://plachta-vits-umamusume-voice-synthesizer.hf.space/file=" +
              message.output.data[1].name;
            break;
        }
      };

      ws.onclose = function (event) {
        if (event.code === 1000) {
          console.log("Process completedï¸");
        } else {
          console.log("Err : WebSocket Connection Error:\n");
        }
        resolve(result);
      };
    });
  },
};
async function bartai(message) {
    const url = 'https://bartai.org';
    const formData = new FormData();

    try {
        const html = await (await fetch(url)).text();
        const $ = cheerio.load(html);

        const chatData = $('.wpaicg-chat-shortcode').map((index, element) => {
            return Object.fromEntries(Object.entries(element.attribs));
        }).get();

        formData.append('_wpnonce', chatData[0]['data-nonce']);
        formData.append('post_id', chatData[0]['data-post-id']);
        formData.append('action', 'wpaicg_chatbox_message');
        formData.append('message', message);

        const response = await fetch('https://bartai.org/wp-admin/admin-ajax.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error('Network response was not ok');

        let resultan = await response.json();
        return resultan.data
    } catch (error) {
        console.error('An error occurred:', error.message);
        throw error;
    }
}
async function chatgptss(message) {
    const url = 'https://chatgptss.org';
    const formData = new FormData();

    try {
        const html = await (await fetch(url)).text();
        const $ = cheerio.load(html);

        const chatData = $('.wpaicg-chat-shortcode').map((index, element) => {
            return Object.fromEntries(Object.entries(element.attribs));
        }).get();

        formData.append('_wpnonce', chatData[0]['data-nonce']);
        formData.append('post_id', chatData[0]['data-post-id']);
        formData.append('action', 'wpaicg_chatbox_message');
        formData.append('message', message);

        const response = await fetch('https://chatgptss.org/wp-admin/admin-ajax.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error('Network response was not ok');

        let resultan = await response.json();
        return resultan.data
    } catch (error) {
        console.error('An error occurred:', error.message);
        throw error;
    }
}


async function bard(message) {
    const url = 'https://bardaifree.com';
    const formData = new FormData();

    try {
        const html = await (await fetch(url)).text();
        const $ = cheerio.load(html);

        const chatData = $('.wpaicg-chat-shortcode').map((index, element) => {
            return Object.fromEntries(Object.entries(element.attribs));
        }).get();

        formData.append('_wpnonce', chatData[0]['data-nonce']);
        formData.append('post_id', chatData[0]['data-post-id']);
        formData.append('action', 'wpaicg_chatbox_message');
        formData.append('message', message);

        const response = await fetch('https://bardaifree.com/wp-admin/admin-ajax.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) throw new Error('Network response was not ok');

        let resultan = await response.json();
        return resultan.data
    } catch (error) {
        console.error('An error occurred:', error.message);
        throw error;
    }
}

class ChatBase {
  static url = "https://www.chatbase.co";
  static supports_gpt_35_turbo = true;
  static supports_gpt_4 = true;
  static working = true;

  static async *createAsyncGenerator(model, messages, kwargs) {
    let chat_id = "";

    if (model === "gpt-4") {
      chat_id = "quran---tafseer-saadi-pdf-wbgknt7zn";
    } else if (model === "gpt-3.5-turbo" || !model) {
      chat_id = "chatbase--1--pdf-p680fxvnm";
    } else {
      throw new Error(`Model are not supported: ${model}`);
    }

    const headers = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
      "Accept": "*/*",
      "Accept-language": "en,fr-FR;q=0.9,fr;q=0.8,es-ES;q=0.7,es;q=0.6,en-US;q=0.5,am;q=0.4,de;q=0.3",
      "Origin": this.url,
      "Referer": this.url + "/",
      "Sec-Fetch-Dest": "empty",
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Site": "same-origin",
    };

    const data = {
      "messages": messages,
      "captchaCode": "hadsa",
      "chatId": chat_id,
      "conversationId": `kcXpqEnqUie3dnJlsRi_O-${chat_id}`
    };

    try {
      const response = await axios.post(`${this.url}/api/fe/chat`, data, { headers: headers });

      if (response.status !== 200) {
        throw new Error(`ChatBase request failed with status code: ${response.status}`);
      }

      const stream = response.data;
      yield stream;
    } catch (error) {
      console.error('Error:', error);
      throw error; // Rethrow the error for handling elsewhere, if needed.
    }
  }

}
async function luminai(q) {
    try {
        const response = await axios.post("https://luminai.siputzx.my.id/", {
            content: q
        });
        return response.data.result;
    } catch (error) {
        console.error('Error fetching:', error);
        throw error;
    }
}

async function Openai2(prompt) {
  const response = await axios({
    method: "POST",
    url: "https://chateverywhere.app/api/chat",
    headers: {
      "Content-Type": "application/json",
      "Cookie": "_ga=GA1.1.34196701.1707462626; _ga_ZYMW9SZKVK=GS1.1.1707462625.1.0.1707462625.60.0.0; ph_phc_9n85Ky3ZOEwVZlg68f8bI3jnOJkaV8oVGGJcoKfXyn1_posthog=%7B%22distinct_id%22%3A%225aa4878d-a9b6-40fb-8345-3d686d655483%22%2C%22%24sesid%22%3A%5B1707462733662%2C%22018d8cb4-0217-79f9-99ac-b77f18f82ac8%22%2C1707462623766%5D%7D",
      Origin: "https://chateverywhere.app",
      Referer: "https://chateverywhere.app/id",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36"
    },
    data: {
      model: {
        id: "gpt-3.5-turbo-0613",
        name: "GPT-3.5",
        maxLength: 12000,
        tokenLimit: 4000,
      },
      prompt: prompt,
      messages: [{
        pluginId: null,
        content: prompt,
        role: "user"
      },
        {
          pluginId: null,
          content: "kamu adalah asisten ai.",
          role: "assistant"
        }]
    }
  })
const res = ({
    developer: "Ripz",
    result: response.data
    })
    return res;
}

module.exports = {
  talkai,
  Openai2, 
  bartai, 
  luminai, 
  BlackBox,
  ChatBase, 
  chatgptss, 
  bard, 
  Gemini,
  soVits,
};

let fs = require("fs");
let chalk = require("chalk");
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update scrape"));
  delete require.cache[file];
  require(file);
});