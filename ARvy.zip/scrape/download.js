const cheerio = require("cheerio");
const formData = require("form-data");

async function igdl(url) {
  return new Promise(async (resolve, reject) => {
    const payload = new URLSearchParams(
      Object.entries({
        url: url,
        host: "instagram"
      })
    )
    await axios.request({
      method: "POST",
      baseURL: "https://saveinsta.io/core/ajax.php",
      data: payload,
      headers: {
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        cookie: "PHPSESSID=rmer1p00mtkqv64ai0pa429d4o",
        "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36"
      }
    })
    .then(( response ) => {      
      const $ = cheerio.load(response.data)
      const mediaURL = $("div.row > div.col-md-12 > div.row.story-container.mt-4.pb-4.border-bottom").map((_, el) => {
        return "https://saveinsta.io/" + $(el).find("div.col-md-8.mx-auto > a").attr("href")
      }).get()
      const res = {
        status: 200,
        media: mediaURL
      }
      resolve(res)
    })
    .catch((e) => {
      console.log(e)
      throw {
        status: 400,
        message: "error",
      }
    })
  })
}
const APIs = {
  1: "https://apkcombo.com",
  2: "apk-dl.com",
  3: "https://apk.support",
  4: "https://apps.evozi.com/apk-downloader",
  5: "http://ws75.aptoide.com/api/7",
  6: "https://cafebazaar.ir",
};
const Proxy = (url) =>
  url
    ? `https://translate.google.com/translate?sl=en&tl=fr&hl=en&u=${encodeURIComponent(url)}&client=webapp`
    : "";
const api = (ID, path = "/", query = {}) =>
  (ID in APIs ? APIs[ID] : ID) +
  path +
  (query
    ? "?" +
      new URLSearchParams(
        Object.entries({
          ...query,
        }),
      )
    : "");

const tools = {
  APIs,
  Proxy,
  api,
};

let apkcombo = {
  search: async function (args) {
    let res = await fetch(
      tools.Proxy(
        tools.api(1, "/search/" + encodeURIComponent(args.replace(" ", "-"))),
      ),
    );
    let ress = [];
    res = await res.text();
    let $ = cheerio.load(res);
    let link = [];
    let name = [];
    $("div.content-apps > a").each(function (a, b) {
      let nem = $(b).attr("title");
      name.push(nem);
      link.push(
        $(b)
          .attr("href")
          .replace(
            "https://apkcombo-com.translate.goog/",
            "https://apkcombo.com/",
          )
          .replace("/?_x_tr_sl=en&_x_tr_tl=fr&_x_tr_hl=en&_x_tr_pto=wapp", ""),
      );
    });
    for (var i = 0; i < (name.length || link.length); i++) {
      ress.push({
        name: name[i],
        link: link[i],
      });
    }
    return ress;
  },
  download: async function (url) {
    let res = await fetch(url);
    res = await res.text();
    let $ = cheerio.load(res);
    let img = $("div.app_header.mt-14 > div.avatar > img").attr("data-src");
    let developer = $(
      "div.container > div > div.column.is-main > div.app_header.mt-14 > div.info > div.author > a",
    ).html();
    let appname = $(
      "div.container > div > div.column.is-main > div.app_header.mt-14 > div.info > div.app_name > h1",
    ).text();
    let link1 =
      "https://apkcombo.com" +
      $(
        "div.container > div > div.column.is-main > div.button-group.mt-14.mb-14.is-mobile-only > a",
      ).attr("href");
    res = await fetch(link1);
    res = await res.text();
    $ = cheerio.load(res);
    let link =
      $("#best-variant-tab > div:nth-child(1) > ul > li > ul > li > a").attr(
        "href",
      ) + "&fp=945d4e52764ab9b1ce7a8fba0bb8d68d&ip=160.177.72.111";
    return {
      img,
      developer,
      appname,
      link,
    };
  },
};

let apkdl = {
  search: async function (args) {
    let res = await fetch(
      tools.Proxy(
        tools.api(2, "/search", {
          q: args,
        }),
      ),
    );
    res = await res.text();

    let $ = cheerio.load(res);

    let link = [];
    let name = [];
    let ress = [];
    $("a.title").each(function (a, b) {
      let nem = $(b).text();
      name.push(nem);
      link.push(
        $(b)
          .attr("href")
          .replace("https://apk--dl-com.translate.goog/", "https://apk-dl.com/")
          .replace("?_x_tr_sl=en&_x_tr_tl=fr&_x_tr_hl=en&_x_tr_pto=wapp", ""),
      );
    });
    for (var i = 0; i < (name.length || link.length); i++) {
      ress.push({
        name: name[i],
        link: link[i],
      });
    }
    return ress;
  },
  download: async function (url) {
    let res = await fetch(tools.Proxy(url));
    res = await res.text();
    let $ = cheerio.load(res);
    let img = $("div.logo > img").attr("src");
    let developer = $("div.developer > a").attr("title");
    let appname = $("div.heading > h1 > a").attr("title");
    let link2 = $(
      "div.download-btn > div > a.mdl-button.mdl-js-button.mdl-button--raised.mdl-js-ripple-effect.fixed-size.mdl-button--primary",
    ).attr("href");
    res = await fetch(link2);
    res = await res.text();
    $ = cheerio.load(res);
    let link1 = $("head > meta:nth-child(11)").attr("content");
    link1 = link1.replace("0; url=", "");
    res = await fetch(link1);
    res = await res.text();
    $ = cheerio.load(res);
    let link =
      `https:// ` +
      $(
        "body > div.mdl-layout.mdl-js-layout.mdl-layout--fixed-header > div > div > div > div > div > div > div:nth-child(1) > div:nth-child(3) > a",
      ).attr("href");
    return { img, developer, appname, link };
  },
};

let aptoide = {
  search: async function (args) {
    let res = await fetch(
      tools.api(5, "/apps/search", {
        query: args,
        limit: 1000,
      }),
    );

    let ress = {};
    res = await res.json();
    ress = res.datalist.list.map((v) => {
      return {
        name: v.name,
        id: v.package,
      };
    });
    return ress;
  },
  download: async function (id) {
    let res = await fetch(
      tools.api(5, "/apps/search", {
        query: id,
        limit: 1,
      }),
    );

    res = await res.json();
    return {
      img: res.datalist.list[0].icon,
      developer: res.datalist.list[0].store.name,
      appname: res.datalist.list[0].name,
      link: res.datalist.list[0].file.path,
    };
  },
};
async function tiktok(query) {
  return new Promise(async (resolve, reject) => {
    try {
      const encodedParams = new URLSearchParams();
      encodedParams.set("url", query);
      encodedParams.set("hd", "1");

      const response = await axios({
        method: "POST",
        url: "https://tikwm.com/api/",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          Cookie: "current_language=en",
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
        },
        data: encodedParams,
      });
      const videos = response.data;
      resolve(videos);
    } catch (error) {
      reject(error);
    }
  });
}
async function facebook(url) {
		let { data } = await axios({ 
			method: 'POST', 
			url: 'https://yt1s.io/api/ajaxSearch/facebook', 
			data: `q=${encodeURIComponent(url)}&vt=facebook` 
		});
		return data;
	}
async function tiktok2(url) {
    try {
        const data = new URLSearchParams({
            'id': url,
            'locale': 'id',
            'tt': 'RFBiZ3Bi'
        });

        const headers = {
            'HX-Request': true,
            'HX-Trigger': '_gcaptcha_pt',
            'HX-Target': 'target',
            'HX-Current-URL': 'https://ssstik.io/id',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
            'Referer': 'https://ssstik.io/id'
        };

        const response = await axios.post('https://ssstik.io/abc?url=dl', data, {
            headers
        });
        const html = response.data;

        const $ = cheerio.load(html);

        const author = $('#avatarAndTextUsual h2').text().trim();
        const title = $('#avatarAndTextUsual p').text().trim();
        const video = $('.result_overlay_buttons a.download_link').attr('href');
        const audio = $('.result_overlay_buttons a.download_link.music').attr('href');
        const imgLinks = [];
        $('img[data-splide-lazy]').each((index, element) => {
            const imgLink = $(element).attr('data-splide-lazy');
            imgLinks.push(imgLink);
        });

        const result = {
            isSlide: video ? false : true,
            author,
            title,
            result: video || imgLinks,
            audio
        };
        return result
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}
module.exports = {
  igdl,
  apkdl,
  apkcombo,
  aptoide,
  tiktok,
  tiktok2, 
  facebook,
};

let fs = require("fs");
let chalk = require("chalk");
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update scrape"));
  delete require.cache[file];
  require(file);
});