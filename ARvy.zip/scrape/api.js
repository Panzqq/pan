const moment = require("moment-timezone");
const { PassThrough } = require("stream");
const axios = require("axios");
const fetch = require("node-fetch");
const cheerio = require("cheerio");

async function ttSearch(query) {
  return new Promise(async (resolve, reject) => {
    axios("https://tikwm.com/api/feed/search", {
      headers: {
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        cookie: "current_language=en",
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
      },
      data: {
        keywords: query,
        count: 12,
        cursor: 0,
        web: 1,
        hd: 1,
      },
      method: "POST",
    }).then((res) => {
      resolve(res.data.data);
    });
  });
}
async function wallpaperhd(chara) {
  return new Promise((resolve, reject) => {
    axios
      .get(
        "https://wall.alphacoders.com/search.php?search=" +
          chara +
          "&filter=4K+Ultra+HD",
      )
      .then(({ data }) => {
        const $ = cheerio.load(data);
        const result = [];
        $("div.boxgrid > a > picture").each(function (a, b) {
          result.push($(b).find("img").attr("src").replace("thumbbig-", ""));
        });
        resolve(result);
      })
      .catch(reject);
  });
}
async function jadianime(url) {
  const { data } = await axios.post(
    "https://tools.revesery.com/image-anime/convert.php",
    new URLSearchParams(
      Object.entries({
        "image-url": url,
      }),
    ),
  );
  const buffer = Buffer.from(data.image.split(",")[1], "base64");
  return conn.sendFile(m.chat, buffer, "", wm, m);
}
async function cai(query, character) {
  try {
    const response = await axios.post(
      "https://boredhumans.com/api_celeb_chat.php",
      `message=${query}&intro=${character}&name=${character}`,
      {
        headers: {
          "User-Agent": "Googlebot-News",
        },
      },
    );
    return response.data;
  } catch (error) {
    throw error;
  }
}
function parseResult(data) {
  let arr = [];
  for (let x of data)
    arr.push({
      id: x.id,
      title: x.title,
      language: x.lang,
      pages: x.num_pages,
      cover:
        x.cover.t.replace(/a.kontol|b.kontol/, "c.kontol") ||
        x.cover.replace(/a.kontol|b.kontol/, "c.kontol"),
    });
  return arr;
}

async function nhentaihome(type = "latest") {
  type = { latest: "all", popular: "popular" }[type];
  await axios
    .get("https://same.yui.pw/api/v4/home")
    .then((res) => parseResult(res.data[type]));
}
async function nhentaisearch(query, sort, page) {
  await axios
    .get(`https://same.yui.pw/api/v4/search/${query}/${sort}/${page}/`)
    .then((res) => parseResult(res.data.result));
}
async function nhentaigetDoujin(id) {
  await axios
    .get(`https://same.yui.pw/api/v4/book/${+id}`)
    .then((res) => res.data);
}
async function nhentaigetRelated(id) {
  await axios
    .get(`https://same.yui.pw/api/v4/book/${+id}/related/`)
    .then((res) => parseResult(res.data.books));
}
async function shortlink(url) {
  isurl = /https?:\/\//.test(url);
  return isurl
    ? (
        await require("axios").get(
          "https://tinyurl.com/api-create.php?url=" + encodeURIComponent(url),
        )
      ).data
    : "";
}
async function Wikipedia(query) {
  const response = await fetch(
    `https://id.m.wikipedia.org/w/index.php?search=${query}`,
  );
  const html = await response.text();
  const $ = cheerio.load(html);

  const contentArray = [];
  $("div.mw-parser-output p").each((index, element) => {
    contentArray.push($(element).text().trim());
  });

  const infoTable = [];
  $("table.infobox tr").each((index, element) => {
    const label = $(element).find("th.infobox-label").text().trim();
    const value =
      $(element).find("td.infobox-data").text().trim() ||
      $(element).find("td.infobox-data a").text().trim();
    if (label && value) {
      infoTable.push(`${label}: ${value}`);
    }
  });

  const data = {
    title: $("title").text().trim(),
    content: contentArray.join("\n"), // Menggabungkan konten menjadi satu string dengan newline separator
    image:
      "https:" +
      ($("#mw-content-text img").attr("src") ||
        "//pngimg.com/uploads/wikipedia/wikipedia_PNG35.png"),
    infoTable: infoTable.join("\n"), // Menggabungkan infoTable menjadi satu string dengan newline separator
  };

  return data;
}
async function cariresep(query) {
  return new Promise(async (resolve, reject) => {
    axios
      .get("https://resepkoki.id/?s=" + query)
      .then(({ data }) => {
        const $ = cheerio.load(data);
        const link = [];
        const judul = [];
        const upload_date = [];
        const format = [];
        const thumb = [];
        $(
          "body > div.all-wrapper.with-animations > div:nth-child(5) > div > div.archive-posts.masonry-grid-w.per-row-2 > div.masonry-grid > div > article > div > div.archive-item-media > a",
        ).each(function (a, b) {
          link.push($(b).attr("href"));
        });
        $(
          "body > div.all-wrapper.with-animations > div:nth-child(5) > div > div.archive-posts.masonry-grid-w.per-row-2 > div.masonry-grid > div > article > div > div.archive-item-content > header > h3 > a",
        ).each(function (c, d) {
          let jud = $(d).text();
          judul.push(jud);
        });
        for (let i = 0; i < link.length; i++) {
          format.push({
            judul: judul[i],
            link: link[i],
          });
        }
        const result = {
          creator: "Bang syaii",
          data: format.filter((v) =>
            v.link.startsWith("https://resepkoki.id/resep"),
          ),
        };
        resolve(result);
      })
      .catch(reject);
  });
}

async function detailresep(query) {
  return new Promise(async (resolve, reject) => {
    axios
      .get(query)
      .then(({ data }) => {
        const $ = cheerio.load(data);
        const abahan = [];
        const atakaran = [];
        const atahap = [];
        $(
          "body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-details > div > div.single-recipe-ingredients-nutritions > div > table > tbody > tr > td:nth-child(2) > span.ingredient-name",
        ).each(function (a, b) {
          let bh = $(b).text();
          abahan.push(bh);
        });
        $(
          "body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-details > div > div.single-recipe-ingredients-nutritions > div > table > tbody > tr > td:nth-child(2) > span.ingredient-amount",
        ).each(function (c, d) {
          let uk = $(d).text();
          atakaran.push(uk);
        });
        $(
          "body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-content > div.single-steps > table > tbody > tr > td.single-step-description > div > p",
        ).each(function (e, f) {
          let th = $(f).text();
          atahap.push(th);
        });
        const judul = $(
          "body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-title.title-hide-in-desktop > h1",
        ).text();
        const waktu = $(
          "body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-meta > ul > li.single-meta-cooking-time > span",
        ).text();
        const hasil = $(
          "body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-meta > ul > li.single-meta-serves > span",
        )
          .text()
          .split(": ")[1];
        const level = $(
          "body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-meta > ul > li.single-meta-difficulty > span",
        )
          .text()
          .split(": ")[1];
        const thumb = $(
          "body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-details > div > div.single-main-media > img",
        ).attr("src");
        let tbahan = "bahan\n";
        for (let i = 0; i < abahan.length; i++) {
          tbahan += abahan[i] + " " + atakaran[i] + "\n";
        }
        let ttahap = "tahap\n";
        for (let i = 0; i < atahap.length; i++) {
          ttahap += atahap[i] + "\n\n";
        }
        const tahap = ttahap;
        const bahan = tbahan;
        const result = {
          creator: "Bang syaii",
          data: {
            judul: judul,
            waktu_masak: waktu,
            hasil: hasil,
            tingkat_kesulitan: level,
            thumb: thumb,
            bahan: bahan.split("bahan\n")[1],
            langkah_langkah: tahap.split("tahap\n")[1],
          },
        };
        resolve(result);
      })
      .catch(reject);
  });
}
async function BingChat(sistem, prompt) {
  let response = await (
    await fetch("https://copilot.github1s.tk/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: "dummy",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "balanced",
        max_tokens: 100,
        messages: [
          {
            role: "system",
            content: sistem,
          },
          {
            role: "user",
            content: prompt,
          },
        ],
      }),
    })
  ).json();
  return response.choices[0].delta.content;
}
function fbdl(link) {
  return new Promise((resolve, reject) => {
    let config = {
      url: link,
    };
    axios("https://www.getfvid.com/downloader", {
      method: "POST",
      data: new URLSearchParams(Object.entries(config)),
      headers: {
        "content-type": "application/x-www-form-urlencoded",
        "user-agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        cookie:
          "_ga=GA1.2.1310699039.1624884412; _pbjs_userid_consent_data=3524755945110770; cto_bidid=rQH5Tl9NNm5IWFZsem00SVVuZGpEd21sWnp0WmhUeTZpRXdkWlRUOSUyQkYlMkJQQnJRSHVPZ3Fhb1R2UUFiTWJuVGlhVkN1TGM2anhDT1M1Qk0ydHlBb21LJTJGNkdCOWtZalRtZFlxJTJGa3FVTG1TaHlzdDRvJTNE; cto_bundle=g1Ka319NaThuSmh6UklyWm5vV2pkb3NYaUZMeWlHVUtDbVBmeldhNm5qVGVwWnJzSUElMkJXVDdORmU5VElvV2pXUTJhQ3owVWI5enE1WjJ4ZHR5NDZqd1hCZnVHVGZmOEd0eURzcSUyQkNDcHZsR0xJcTZaRFZEMDkzUk1xSmhYMlY0TTdUY0hpZm9NTk5GYXVxWjBJZTR0dE9rQmZ3JTNEJTNE; _gid=GA1.2.908874955.1625126838; __gads=ID=5be9d413ff899546-22e04a9e18ca0046:T=1625126836:RT=1625126836:S=ALNI_Ma0axY94aSdwMIg95hxZVZ-JGNT2w; cookieconsent_status=dismiss",
      },
    })
      .then(async ({ data }) => {
        const $ = cheerio.load(data);
        resolve({
          Normal_video: $(
            "body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(1) > a",
          ).attr("href"),
          HD: $(
            "body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(1) > a",
          ).attr("href"),
          audio: $(
            "body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(2) > a",
          ).attr("href"),
        });
      })
      .catch(reject);
  });
}
async function gore() {
  return new Promise((resolve, reject) => {
    const page = Math.floor(Math.random() * 228);
    axios.get("https://seegore.com/gore/page/" + page).then((res) => {
      const $ = cheerio.load(res.data);
      const link = [];
      $("ul > li > article").each(function (a, b) {
        link.push({
          title: $(b).find("div.content > header > h2").text(),
          link: $(b).find("div.post-thumbnail > a").attr("href"),
          thumb: $(b).find("div.post-thumbnail > a > div > img").attr("src"),
          view: $(b)
            .find(
              "div.post-thumbnail > div.post-meta.bb-post-meta.post-meta-bg > span.post-meta-item.post-views",
            )
            .text(),
          vote: $(b)
            .find(
              "div.post-thumbnail > div.post-meta.bb-post-meta.post-meta-bg > span.post-meta-item.post-votes",
            )
            .text(),
          tag: $(b)
            .find("div.content > header > div > div.bb-cat-links")
            .text(),
          comment: $(b)
            .find("div.content > header > div > div.post-meta.bb-post-meta > a")
            .text(),
        });
      });
      const random = link[Math.floor(Math.random() * link.length)];
      axios.get(random.link).then((resu) => {
        const $$ = cheerio.load(resu.data);
        const hasel = {};
        hasel.title = random.title;
        hasel.source = random.link;
        hasel.thumb = random.thumb;
        hasel.tag = $$("div.site-main > div > header > div > div > p").text();
        hasel.upload = $$("div.site-main")
          .find("span.auth-posted-on > time:nth-child(2)")
          .text();
        hasel.author = $$("div.site-main")
          .find("span.auth-name.mf-hide > a")
          .text();
        hasel.comment = random.comment;
        hasel.vote = random.vote;
        hasel.view = $$("div.site-main")
          .find(
            "span.post-meta-item.post-views.s-post-views.size-lg > span.count",
          )
          .text();
        hasel.video1 = $$("div.site-main").find("video > source").attr("src");
        hasel.video2 = $$("div.site-main").find("video > a").attr("href");
        resolve(hasel);
      });
    });
  });
}

async function HariLibur() {
  const { data } = await axios.get("https://www.liburnasional.com/");
  let libnas_content = [];
  let $ = cheerio.load(data);
  let result = {
    nextLibur:
      "Hari libur" +
      $("div.row.row-alert > div").text().split("Hari libur")[1].trim(),
    libnas_content,
  };
  $("tbody > tr > td > span > div").each(function (a, b) {
    summary = $(b).find("span > strong > a").text();
    days = $(b).find("div.libnas-calendar-holiday-weekday").text();
    dateMonth = $(b).find("time.libnas-calendar-holiday-datemonth").text();
    libnas_content.push({ summary, days, dateMonth });
  });
  return result;
}
class Drakor {
  search = async (query) => {
    try {
      const response = await fetch(
        "https://drakorasia.us?s=" + query + "&post_type=post",
      );
      const html = await response.text();
      const $ = cheerio.load(html);
      const extractedData = $("#post.archive")
        .map((index, element) => ({
          title: $(element).find("h2 a").text().trim(),
          link: $(element).find("h2 a").attr("href"),
          image: $(element).find("img").attr("src"),
          categories: $(element)
            .find('.genrenya span[rel="tag"]')
            .map((index, el) => $(el).text())
            .get(),
          year: $(element).find('.category a[rel="tag"]').text(),
          episodes: $(element)
            .find(".category")
            .contents()
            .filter((index, el) => el.nodeType === 3)
            .text()
            .trim(),
        }))
        .get();
      return extractedData;
    } catch (error) {
      console.error("Error:", error);
      return [];
    }
  };
  download = async (url) => {
    try {
      const response = await fetch(url);
      const html = await response.text();
      const $ = cheerio.load(html);
      const genres = $('.genrenya span[rel="tag"]')
        .map(function (_, el) {
          return $(el).text().trim();
        })
        .get();
      const resolutions = $("thead th")
        .filter(function (_, el) {
          return $(el).text().includes("Download");
        })
        .map(function (_, el) {
          return $(el).text().trim().replace("Download ", "").toLowerCase();
        })
        .get();
      return {
        title: $("h2 span.border-b-4").text().trim(),
        synopsis: $("#synopsis p.caps strong").text().trim(),
        rating: $(".wpd-rating-value .wpdrv").text(),
        genres,
        downloadInfo: $("#content-post table.mdl-data-table tbody tr")
          .map(function (_, el) {
            const episode = $(el).find("td:first-child").text().trim();
            const episodeInfo = Object.fromEntries(
              resolutions.map(function (resolution) {
                const columnIndex = $(
                  'thead th:contains("Download ' + resolution + '")',
                ).index();
                const resolutionColumn = $(el).find(
                  "td:eq(" + columnIndex + ")",
                );
                const downloadLinks = resolutionColumn
                  .find("a")
                  .map(function (_, a) {
                    const link = $(a).attr("href");
                    const platform = $(a).text().trim();
                    return {
                      platform,
                      link,
                    };
                  })
                  .get();
                return [resolution, downloadLinks];
              }),
            );
            return {
              episode,
              episodeInfo,
            };
          })
          .get(),
      };
    } catch (error) {
      console.error("Error:", error);
      return {};
    }
  };
}

async function tiktokTts(text, model) {
  try {
    const modelVoice = model ? model : "en_us_001";
    const { status, data } = await axios.post(
      "https://tiktok-tts.weilnet.workers.dev/api/generation",
      {
        text: text,
        voice: modelVoice,
      },
      {
        headers: {
          "content-type": "application/json",
        },
      },
    );
    return data;
  } catch (err) {
    console.log(err.response.data);
    return err.response.data;
  }
}

async function ttsModel() {
  try {
    const response = await axios.get("https://tiktokvoicegenerator.com");
    const $ = cheerio.load(response.data);

    return $('select#voice option[value*="_"]')
      .get()
      .map((option) => ({
        title: $(option).text().trim(),
        id: $(option).attr("value"),
      }));
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    return [];
  }
}

async function findSongs(text) {
  try {
    const { data } = await axios.get(
      "https://songsear.ch/q/" + encodeURIComponent(text),
    );
    const $ = cheerio.load(data);
    const result = {
      title:
        $("div.results > div:nth-child(1) > .head > h3 > b").text() +
        " - " +
        $("div.results > div:nth-child(1) > .head > h2 > a").text(),
      album: $("div.results > div:nth-child(1) > .head > p").text(),
      number: $("div.results > div:nth-child(1) > .head > a")
        .attr("href")
        .split("/")[4],
      thumb: $("div.results > div:nth-child(1) > .head > a > img").attr("src"),
    };

    const { data: lyricData } = await axios.get(
      `https://songsear.ch/api/song/${result.number}?text_only=true`,
    );
    const lyrics = lyricData.song.text_html
      .replace(/<br\/>/g, "\n")
      .replace(/&#x27;/g, "'");

    return {
      status: true,
      title: result.title,
      album: result.album,
      thumb: result.thumb,
      lyrics: lyrics,
    };
  } catch (err) {
    console.log(err);
    return {
      status: false,
      error: "Unknown error occurred",
    };
  }
}
module.exports = {
  ttSearch,
  Wikipedia,
  cariresep,
  detailresep,
  gore,
  HariLibur,
  Drakor,
  tiktokTts,
  ttsModel,
  findSongs,
};

let fs = require("fs");
let chalk = require("chalk");
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update scrape"));
  delete require.cache[file];
  require(file);
});